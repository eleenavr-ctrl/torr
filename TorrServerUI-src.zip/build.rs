fn main() {
    let config = slint_build::CompilerConfiguration::new()
        .with_style("fluent".into());
    slint_build::compile_with_config("ui/app.slint", config)
        .expect("Failed to compile Slint UI with Fluent style");
}
